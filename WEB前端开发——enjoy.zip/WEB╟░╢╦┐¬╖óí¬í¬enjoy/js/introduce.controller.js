(function () {
    'use strict';
    angular.module('enjoyApp')
        .controller('introduce.Controller',function () {

        })
})();