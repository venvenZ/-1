(function () {
    'use strict';
    angular.module('enjoyApp',['ui.router','oc.lazyLoad'])
        .controller('enjoyCtl',enjoyCtl)





    /*index控制器*/
    function enjoyCtl() {
        //$state.go('login')
    }
})()